#!/bin/bash
oldpwd=$(pwd)
cd $(dirname $0)
sudo cp 57-cypress_programmer.rules /etc/udev/rules.d/
sudo cp 70-wiced-JTAG.rules /etc/udev/rules.d/
pushd "../openocd/udev_rules/"
sudo cp 60-openocd.rules /etc/udev/rules.d/
sudo cp 66-wiced-JTAG.rules /etc/udev/rules.d/
popd
sudo service udev restart
sudo udevadm control --reload
sudo udevadm trigger --action=add
cd $oldpwd
